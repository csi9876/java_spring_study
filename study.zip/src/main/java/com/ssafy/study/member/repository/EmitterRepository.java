package com.ssafy.study.member.repository;

public class EmitterRepository {
}
